<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="Tiles Escritório" tilewidth="1200" tileheight="804" tilecount="47" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="101" height="151" source="Tile 1 - Armário 100 x 150.png"/>
 </tile>
 <tile id="1">
  <image width="101" height="51" source="Tile 2 - Mesa 100 x 50.png"/>
 </tile>
 <tile id="2">
  <image width="101" height="26" source="Tile 3 - Mesinha 100 x 25.png"/>
 </tile>
 <tile id="3">
  <image width="54" height="43" source="Tile 4 - Computador.png"/>
 </tile>
 <tile id="4">
  <image width="26" height="12" source="Tile 5 - Pilha de Papel.png"/>
 </tile>
 <tile id="5">
  <image width="101" height="51" source="Tile 6 - Pilha de Papel mortal.png"/>
 </tile>
 <tile id="6">
  <image width="14" height="26" source="Tile 9 - Porta-lápis.png"/>
 </tile>
 <tile id="7">
  <image width="101" height="51" source="Tile 7 - Pilha de Papel mortal pontas.png"/>
 </tile>
 <tile id="8">
  <image width="50" height="51" source="Tile 8 - Placa.png"/>
 </tile>
 <tile id="9">
  <image width="51" height="37" source="Tile 10 - Impressora.png"/>
 </tile>
 <tile id="10">
  <image width="50" height="51" source="Tile 11 - Lâmpada baixa.png"/>
 </tile>
 <tile id="11">
  <image width="51" height="101" source="Tile 12 - lâmpada média.png"/>
 </tile>
 <tile id="12">
  <image width="51" height="151" source="Tile 13 - Lâmpada Alta.png"/>
 </tile>
 <tile id="13">
  <image width="1200" height="804" source="BG.png"/>
 </tile>
 <tile id="14">
  <image width="101" height="151" source="Tile 14 - Armário .png"/>
 </tile>
 <tile id="15">
  <image width="101" height="151" source="Tile 15 - Armário .png"/>
 </tile>
 <tile id="16">
  <image width="51" height="101" source="Tile 15 - Porta Final.png"/>
 </tile>
 <tile id="17">
  <image width="50" height="50" source="Tile.png"/>
 </tile>
 <tile id="18">
  <image width="51" height="51" source="Tile 16 - Metade Mesa Esquerda.png"/>
 </tile>
 <tile id="19">
  <image width="51" height="51" source="Tile 17 - Metade Mesa Direita.png"/>
 </tile>
 <tile id="20">
  <image width="51" height="51" source="Tile 18 - Metade Prateleira Esquerda.png"/>
 </tile>
 <tile id="21">
  <image width="51" height="51" source="Tile 19 - Metade Prateleira Direita.png"/>
 </tile>
 <tile id="22">
  <image width="51" height="51" source="Tile 20 - Pontinha armário.png"/>
 </tile>
 <tile id="23">
  <image width="51" height="801" source="Tira 1 .png"/>
 </tile>
 <tile id="24">
  <image width="51" height="801" source="Tira 2.png"/>
 </tile>
 <tile id="25">
  <image width="51" height="801" source="Tira 3.png"/>
 </tile>
 <tile id="26">
  <image width="51" height="801" source="Tira 4.png"/>
 </tile>
 <tile id="27">
  <image width="51" height="801" source="Tira 5.png"/>
 </tile>
 <tile id="28">
  <image width="51" height="801" source="Tira 6.png"/>
 </tile>
 <tile id="29">
  <image width="51" height="801" source="Tira 7.png"/>
 </tile>
 <tile id="30">
  <image width="51" height="801" source="Tira 8.png"/>
 </tile>
 <tile id="31">
  <image width="51" height="801" source="Tira 9.png"/>
 </tile>
 <tile id="32">
  <image width="51" height="801" source="Tira 10.png"/>
 </tile>
 <tile id="33">
  <image width="51" height="801" source="Tira 11.png"/>
 </tile>
 <tile id="34">
  <image width="51" height="801" source="Tira 12.png"/>
 </tile>
 <tile id="35">
  <image width="51" height="801" source="Tira 13.png"/>
 </tile>
 <tile id="36">
  <image width="51" height="801" source="Tira 14.png"/>
 </tile>
 <tile id="37">
  <image width="51" height="801" source="Tira 15.png"/>
 </tile>
 <tile id="38">
  <image width="51" height="801" source="Tira 16.png"/>
 </tile>
 <tile id="39">
  <image width="51" height="801" source="Tira 17.png"/>
 </tile>
 <tile id="40">
  <image width="51" height="801" source="Tira 18.png"/>
 </tile>
 <tile id="41">
  <image width="51" height="801" source="Tira 19.png"/>
 </tile>
 <tile id="42">
  <image width="51" height="801" source="Tira 20.png"/>
 </tile>
 <tile id="43">
  <image width="51" height="801" source="Tira 21.png"/>
 </tile>
 <tile id="44">
  <image width="51" height="801" source="Tira 22.png"/>
 </tile>
 <tile id="45">
  <image width="51" height="801" source="Tira 23.png"/>
 </tile>
 <tile id="46">
  <image width="51" height="801" source="Tira 24.png"/>
 </tile>
</tileset>
